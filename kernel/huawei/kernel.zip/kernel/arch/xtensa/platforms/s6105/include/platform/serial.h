#ifndef __ASM_XTENSA_S6105_SERIAL_H
#define __ASM_XTENSA_S6105_SERIAL_H

#include <variant/hardware.h>

#define BASE_BAUD (S6_SCLK / 16)

#endif /* __ASM_XTENSA_S6105_SERIAL_H */
